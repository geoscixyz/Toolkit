Geophysical Toolkit
===================

A collection of geophysical apps for geologists, from the collaboration of
MDRU and UBC-GIF

.. image:: ./docs/images/MDRU.png
   :scale: 100%
   :align: left

.. image:: ./docs/images/GIF.png
   :scale: 100%
   :align: right
